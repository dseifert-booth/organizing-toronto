<?php
			global $old_url, $old_file_path;
			$old_url = 'http://organizingtoronto.com';
			$old_file_path = '/home/andrewn29/public_html/';
			