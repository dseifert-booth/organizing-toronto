<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:2:{s:20:"whitelistedURLParams";a:1:{s:49:"Lw==|cmVxdWVzdC5maWxlTmFtZXNbeWl3X2NvbnRhY3RdWzBd";a:1:{i:11;a:4:{s:9:"timestamp";i:1466495155;s:11:"description";s:35:"Whitelisted while in Learning Mode.";s:2:"ip";s:13:"62.210.152.87";s:6:"userID";i:0;}}}s:4:"cron";a:3:{i:0;O:24:"wfWAFCronFetchRulesEvent":1:{s:11:" * fireTime";i:1579061490;}i:1;O:25:"wfWAFCronFetchIPListEvent":1:{s:11:" * fireTime";i:1578953140;}i:2;O:36:"wfWAFCronFetchBlacklistPrefixesEvent":1:{s:11:" * fireTime";i:1578883196;}}}