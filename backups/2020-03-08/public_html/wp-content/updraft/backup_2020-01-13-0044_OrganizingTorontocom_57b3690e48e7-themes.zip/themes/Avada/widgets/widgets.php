<?php
include_once('tabs_widget.php');

include_once('tweets-widget.php');
include_once('flickr-widget.php');
include_once('facebook-like-widget.php');

include_once('125_125.php');
include_once('social_links.php');

include_once('contact_info.php');
include_once('recent-works-widget.php');