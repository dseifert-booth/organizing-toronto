<?php
$this->text(	'caption_1',
				'Title',
				''
			);
?>
<?php
$this->text(	'caption_2',
				'Caption',
				''
			);
?>